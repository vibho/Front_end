import React from 'react';
import './Logo.scss';

const Logo = () => <a href="/" className="logo uppercase">Logo</a>;

export default Logo;
